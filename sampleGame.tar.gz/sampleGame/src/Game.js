import React from 'react'

class Game extends React.Component {
    render(){
        return (
            <div>
                <h1>Blacks Turn</h1>
                <Board />
                <button>Restart</button>
            </div>
        )
    }
}